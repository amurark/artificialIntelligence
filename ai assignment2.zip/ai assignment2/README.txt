DOCUMENTATION
=============

To run the program:
1. Open the terminal or the comman prompt.
2. Change directory to ./ai-ass2/bin
3. To run greedy search algorithm: type "java SearchUSA greedy city1 city2".
4. To run uniform search algorithm: type "java SearchUSA uniform city1 city2".
5. To run astar search algorithm: type "java SearchUSA astar city1 city2".